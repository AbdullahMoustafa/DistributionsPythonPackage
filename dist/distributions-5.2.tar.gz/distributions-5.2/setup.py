from setuptools import setup

setup(name='distributions',
	version='5.2',
	description = 'Gaussian distribution',
	packages= ['distributions'],
	zip_safe=False)